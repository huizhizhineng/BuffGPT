from config.get_config import get_config_parser

app_config = get_config_parser()
